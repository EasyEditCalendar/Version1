#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 22 14:07:55 2021

@author: user
"""

from Main import main, getEvents

#used for GUI
import tkinter as tk 

    
window.mainloop()